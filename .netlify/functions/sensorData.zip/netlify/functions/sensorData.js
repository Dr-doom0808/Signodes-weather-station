const axios = require('axios');

// Import API configuration
const { SCRIPT_ID, getUVRisk } = require('../../src/config/api.cjs');

// Google Apps Script URL - This should be set as an environment variable in Netlify
const GOOGLE_SCRIPT_URL = process.env.GOOGLE_SCRIPT_URL || 
  `https://script.google.com/macros/s/${SCRIPT_ID}/exec`;

// Main handler function
exports.handler = async (event, context) => {
  // Only allow GET requests
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method Not Allowed' }),
    };
  }

  try {
    // Get the 'sts' parameter from the query string
    const { sts } = event.queryStringParameters || {};
    
    // Build the URL with query parameters
    const params = new URLSearchParams();
    if (sts) {
      params.append('sts', sts);
    }
    
    const url = `${GOOGLE_SCRIPT_URL}?${params.toString()}`;
    
    // Fetch data from Google Apps Script
    const response = await axios.get(url, {
      responseType: 'text',
      timeout: 30000, // 30 second timeout
    });

    const textData = response.data;
    let sensorData = [];
    
    // Check if the response is JSON format (for readrange queries)
    if (textData.trim().startsWith('[')) {
      try {
        const jsonData = JSON.parse(textData);
        if (Array.isArray(jsonData) && jsonData.length > 0) {
          // Handle JSON array format
          sensorData = jsonData.map((row, index) => {
            if (!Array.isArray(row) || row.length < 10) {
              return null;
            }
            
            return {
              id: `node-${index + 1}`,
              name: 'Node A',
              location: 'Main Campus',
              temperature: parseFloat(row[2]) || 0,
              pressure: parseFloat(row[1]) || 0,
              humidity: parseFloat(row[3]) || 0,
              aqi25val: parseFloat(row[6]) || 0,
              aqi10val: parseFloat(row[5]) || 0,
              uvIndex: parseFloat(row[14]) || 0,
              uvRisk: getUVRisk(parseFloat(row[14]) || 0),
              rain: row[13] === 'Yes' ? 'Yes' : 'No',
              lastUpdated: row[0] || new Date().toISOString().replace('T', '_').split('.')[0]
            };
          }).filter(item => item !== null);
        }
      } catch (parseError) {
        console.error('Failed to parse JSON data:', parseError);
      }
    } else {
      // Parse as CSV data
      const rows = textData.split('\n').filter(row => row.trim() !== '');
      
      if (rows.length === 0) {
        throw new Error('No data received from Google Apps Script');
      }

      sensorData = rows.map(row => {
        const columns = row.split(',');
        
        if (columns.length < 10) {
          return null; // Skip invalid rows
        }

        return {
          id: 'node-1',
          name: 'Node A',
          location: 'Main Campus',
          temperature: parseFloat(columns[2]) || 0,
          pressure: parseFloat(columns[1]) || 0,
          humidity: parseFloat(columns[3]) || 0,
          aqi25val: parseFloat(columns[6]) || 0,
          aqi10val: parseFloat(columns[5]) || 0,
          uvIndex: parseFloat(columns[14]) || 0,
          uvRisk: getUVRisk(parseFloat(columns[14]) || 0),
          rain: columns[13] === 'Yes' ? 'Yes' : 'No',
          lastUpdated: columns[0] || new Date().toISOString().replace('T', '_').split('.')[0]
        };
      }).filter(item => item !== null);
    }

    if (sensorData.length === 0) {
      throw new Error('No valid data could be processed');
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
      },
      body: textData, // Return the raw data from Google Apps Script
    };

  } catch (error) {
    console.error('Error fetching sensor data:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        error: 'Failed to fetch sensor data',
        details: error.message
      }),
    };
  }
};

// Helper function is now imported from config/api.js
