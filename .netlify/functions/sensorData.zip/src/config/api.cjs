// API Configuration (CommonJS version for Netlify functions)

// Google Apps Script URL
const SCRIPT_ID = process.env.GOOGLE_SCRIPT_ID || process.env.VITE_GOOGLE_SCRIPT_ID || 'AKfycbxRpVtuGkPIcao_s891Jrj16izDFEh1yRAwsv_fk9ZYKRrWy8u0yieuk4QEm-BCNehc3A';
const GOOGLE_SCRIPT_URL = `https://script.google.com/macros/s/${SCRIPT_ID}/exec`;

// API Base URL for development and production
const API_BASE = '/api';

// Column index mapping for sensor data
const COLS = {
  datetime: 0,
  pressure: 1,
  temperature: 2,
  humidity: 3,
  aqi10: 5,
  aqi25: 6,
  rain: 13,
  uvIndex: 14,
  uvRisk: 15,
  mq_co: 16,  // MQ-7 Carbon Monoxide sensor column
};

// Helper function to determine UV risk level
function getUVRisk(uvIndex) {
  if (uvIndex <= 2) return 'Low';
  if (uvIndex <= 5) return 'Moderate';
  if (uvIndex <= 7) return 'High';
  if (uvIndex <= 10) return 'Very High';
  return 'Extreme';
}

// Export for CommonJS
module.exports = {
  SCRIPT_ID,
  GOOGLE_SCRIPT_URL,
  API_BASE,
  COLS,
  getUVRisk
};